import OrderDetails from "../ui/OrderDetails";

const OrderDetailsPage = () => {
  return <OrderDetails />;
};

export default OrderDetailsPage;
