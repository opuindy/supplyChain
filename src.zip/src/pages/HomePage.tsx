import Home from "../ui/Home";

const HomePage = () => {
  return <Home />;
};

export default HomePage;
