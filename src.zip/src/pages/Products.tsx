import ProductList from "../ui/ProductList";

const Products = () => {
  return <ProductList />;
};

export default Products;
