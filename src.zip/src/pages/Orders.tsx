import OrderList from "../ui/OrderList";

const Orders = () => {
  return <OrderList />;
};

export default Orders;
