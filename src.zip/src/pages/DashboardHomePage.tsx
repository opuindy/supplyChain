const DashboardHomePage = () => {
  return (
    <section className="flex h-full w-full items-center justify-center">
      <h1 className="text-3xl font-semibold">Welcome</h1>
    </section>
  );
};

export default DashboardHomePage;
