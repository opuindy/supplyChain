import ProductDetails from "../ui/ProductDetails";

const ProductDetailsPage = () => {
  return <ProductDetails />;
};

export default ProductDetailsPage;
