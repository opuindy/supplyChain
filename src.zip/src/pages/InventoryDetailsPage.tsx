import InventoryDetails from "../ui/InventoryDetails";

const InventoryDetailsPage = () => {
  return <InventoryDetails />;
};

export default InventoryDetailsPage;
