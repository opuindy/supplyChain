import NewOrderForm from "../ui/NewOrderForm";

const CreateNewOrder = () => {
  return <NewOrderForm />;
};

export default CreateNewOrder;
