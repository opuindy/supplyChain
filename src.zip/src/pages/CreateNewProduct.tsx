import NewProductForm from "../ui/NewProductForm";

const CreateNewProduct = () => {
  return <NewProductForm />;
};

export default CreateNewProduct;
