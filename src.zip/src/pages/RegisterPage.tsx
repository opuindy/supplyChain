import Register from "../ui/Register";

const RegisterPage = () => {
  return <Register />;
};

export default RegisterPage;
