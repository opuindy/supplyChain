import NewInventoryForm from "../ui/NewInventoryForm";

const CreateNewInventory = () => {
  return <NewInventoryForm />;
};

export default CreateNewInventory;
