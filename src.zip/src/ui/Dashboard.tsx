import DashboardLayout from "./DashboardLayout";

const Dashboard = () => {
  return <DashboardLayout />;
};

export default Dashboard;
