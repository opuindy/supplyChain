import InventoryList from "./InventoryList";

const Inventory = () => {
  return <InventoryList />;
};

export default Inventory;
