import { useParams } from "react-router-dom";
import { inventory } from "../utils/data";

const InventoryDetails = () => {
  const { id } = useParams<{ id: string }>();
  const item = inventory.find((item) => item.id === id);

  if (!item) {
    return (
      <div className="m-auto mt-8 flex min-h-72 w-[800px] items-center justify-center text-3xl font-bold text-primary">
        Item not found!
      </div>
    );
  }

  const {
    productName,
    productType,
    quantityInStock,
    stockingDate,
    storageDetails,
    displayInformation,
    saleDate,
    customerName,
    customerContact,
    additionalInfo,
  } = item;

  return (
    <div className="m-auto mb-4 mt-6 w-[800px] space-y-8 overscroll-y-auto rounded-lg border border-lightGray bg-background px-6 py-8 shadow-md">
      <h1 className="mb-4 text-3xl font-bold text-secondary">
        Inventory Details
      </h1>
      <div className="space-y-6">
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Product Name:</label>
          <p className="text-text">{productName}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Product Type:</label>
          <p className="text-text">{productType}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Quantity In Stock:</label>
          <p className="text-text">{quantityInStock}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Stocking Date:</label>
          <p className="text-text">{stockingDate}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Storage Details:</label>
          <p className="text-text">{storageDetails}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Display Information:</label>
          <p className="text-text">{displayInformation}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Sale Date:</label>
          <p className="text-text">{saleDate}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Customer Name:</label>
          <p className="text-text">{customerName}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Customer Contact:</label>
          <p className="text-text">{customerContact}</p>
        </div>
        <div className="border-b border-border pb-4">
          <label className="font-bold text-darkGray">Additional Information:</label>
          <p className="text-text">{additionalInfo}</p>
        </div>
      </div>
    </div>
  );
};

export default InventoryDetails;
